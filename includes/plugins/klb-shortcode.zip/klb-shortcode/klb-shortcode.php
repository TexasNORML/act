<?php 
    /*
    Plugin Name: Klb Shortcode
    Plugin URI: http://themeforest.net/user/klbtheme/portfolio
    Description: Plugin for displaying theme shortcodes.
    Author: KlbTheme
    Version: 1.4
    Author URI: http://themeforest.net/user/klbtheme/portfolio
    */

/*-----------------------------------------------------------------------------------*/
/*	Act Home Image
/*-----------------------------------------------------------------------------------*/

function act_home_image( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "image_url"    => '',
		"values"       => '',
		"link"         => '',
		"contentm"     => '',
		"texttime"     => '7000',
        "overlay"      => '',
    ), $atts) );
	
            $output = '';
            $values = (array) vc_param_group_parse_atts($values);

		    $image_urls = wp_get_attachment_url( $image_url, 'full' );
			
			wp_enqueue_script('custom-home'); 
			wp_localize_script('custom-home', 'home' , 
			   array( 
				 'time' => $texttime,
				));	
				
			$output .= '<div class="klbintro" style="background-image:url('.$image_urls.') ;">';
            if($overlay != 'yes'){
			$output .= '<div class="overlay-dark">';
            }
			$output .= '<div class="intro-body">';
			$output .= '<div class="row">';
			$output .= '<div class="col-md-12">';
			$output .= '<div class="carousel-wrapper">';
			$output .= '<div class="carousel slide carousel-fade">';
			$output .= '<div class="carousel-inner">';   
            
			$klb = 0;
			foreach($values as $v){
				
			$link = ( '||' === $v['link'] ) ? '' : $v['link'];
			$link = vc_build_link( $v['link'] );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			
			$class = "";
			if($klb++ == 0){
				$class .= "active";
			}
			
			$output .= '<div class="item '.$class.'">';
			$output .= '<span class="text-big">'.$v['contentm'].'</span><br>';
			$output .= '<a href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'" class="btn btn-outline btn-xl">'.esc_attr( $a_title ).'</a>';
			$output .= '</div>';
			}
			
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
            if($overlay != 'yes'){
			$output .= '</div>';
			}	
			$output .= '</div>';

  		return $output;
}

add_shortcode('home_image', 'act_home_image');


/*-----------------------------------------------------------------------------------*/
/*	Act Carousel
/*-----------------------------------------------------------------------------------*/

function act_carousel( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    => '',
		"values"       => '',
		"link"         => '',
		"contentm"     => '',
		"texttime"     => '7000',
    ), $atts) );
	
            $output = '';
            $values = (array) vc_param_group_parse_atts($values);

			
			wp_enqueue_script('custom-carousel'); 
			wp_localize_script('custom-carousel', 'carousel' , 
			   array( 
				 'time' => $texttime,
				));	
				
			$output .= '<div class="klbcarousel text-center inner-container">';
			if($title){
			$output .= '<h1>'.$title.'</h1>';
			$output .= '<div class="accent-rule-short"></div>';
			}
			$output .= '<div class="vert-centered-wrapper-150px">';
			$output .= '<div class="vert-centered">';
			$output .= '<div class="carousel slide carousel-fade" id="carousel_fade">';
			$output .= '<div class="carousel-inner">';
			$klb = 0;
			foreach($values as $v){
			$class = "";
			if($klb++ == 0){
				$class .= "active";
			}
			
			$output .= '<div class="item '.$class.'">';
			$output .= '<h2>'.$v['contentm'].'</h2>';
			$output .= '</div>';
            }

			$output .= '</div>'; 
			
			$output .= '<a class="left carousel-control carousel-control-wide" href="#carousel_fade" role="button" data-slide="prev">';
			$output .= '<span class="glyphicon glyphicon-chevron-left"></span>';
			$output .= '</a>';
			
			$output .= '<a class="right carousel-control carousel-control-wide" href="#carousel_fade" role="button" data-slide="next">';
			$output .= '<span class="glyphicon glyphicon-chevron-right"></span>';
			$output .= '</a>';
			
			$output .= '</div>'; 
			$output .= '</div>';   
			$output .= '</div>';
			$output .= '</div>';

  		return $output;
}

add_shortcode('carousel', 'act_carousel');


/*-----------------------------------------------------------------------------------*/
/*	Act Process Box
/*-----------------------------------------------------------------------------------*/

function act_process_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    => '',
		"link"                 => '',
		"contentm"             => '',
        "icon_fontawesome"   => '',
        "icon_openiconic"   => '',
        "icon_typicons"   => '',
        "icon_entypo"   => '',
        "icon_linecons"   => '',
        "icon_monosocial"   => '',
		"type"     => '',
		"bgcolor"     => '',
    ), $atts) );
	
            $output = '';
			
			$link = ( '||' === $link ) ? '' : $link;
			$link = vc_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			
            vc_icon_element_fonts_enqueue( $type ); 

			$output .= '<div class="bg-brand-warning process-box" style="background-color:'.esc_attr($bgcolor).';">';
			$output .= '<div class="responsive-hide">';
			$output .= '<div class="triangle-right wow animated-longer-delay-3 fadeIn"><span class="text-big"><i class="fa fa-caret-right text-warning" style="color:'.esc_attr($bgcolor).';"></i></span></div>';
			$output .= '</div>';
			$output .= '<div class="col-lg-12 col-md-12 inner-container-small wow animated fadeIn" data-wow-offset="10">';
			$output .= '<div class="pull-left icon-circle-md">';
			$output .= '<button class="btn-circle btn-white"><i class="';
			
			if(isset($icon_fontawesome)){
			$output .= $icon_fontawesome;	
			}
			if(isset($icon_openiconic)){
			$output .= $icon_openiconic;
			} 
            if(isset($icon_typicons)){
			$output .= $icon_typicons;
			}
			if(isset($icon_entypo)){
			$output .= $icon_entypo;
			}
			if(isset($icon_linecons)){
			$output .= $icon_linecons;
			}
			if(isset($icon_monosocial)){
			$output .= $icon_monosocial;
			}
			$output .= ' fa-2x"></i></button>';
			$output .= '</div>';
			$output .= '<div class="col-lg-9 col-md-9">';
			$output .= '<h2>'.$title.'</h2>';
			$output .= '<p> '.$contentm.'<br><br>';
			if($a_title){
			$output .= '<a href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'" class="btn btn-black btn-sm">'.esc_attr( $a_title ).'</a>';
            }
			$output .= '</p>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';

  		return $output;
}

add_shortcode('process_box', 'act_process_box');

/*-----------------------------------------------------------------------------------*/
/*	Act Title
/*-----------------------------------------------------------------------------------*/

function act_title( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    => '',
		"subtitle"               => '',
		"textalign"              => '',
		"fontcolor"              => '#000',
		"bordercolor"            => '',
    ), $atts) );
	
            $output = '';
			
			$style = '';
			if($textalign == 'center'){
			  $style .= 'style="text-align:center"';
			} elseif($textalign == 'right'){
			  $style .= 'style="text-align:right"';
			} else {
			  $style .= 'style="text-align:left"';
			}

			$output .= '<div class="klb-title" '.$style.'>';
			$output .= '<h1 style="color:'.$fontcolor.'">'.$title.'</h1>';
			$output .= '<div class="accent-rule-short" style="border-top:1px solid '.$bordercolor.' !important;"></div>';
			$output .= '<h2 style="color:'.$fontcolor.'">'.$subtitle.'</h2>';
			$output .= '</div>';

  		return $output;
}

add_shortcode('title', 'act_title');

/*-----------------------------------------------------------------------------------*/
/*	Act Latest Blog
/*-----------------------------------------------------------------------------------*/

function act_blog($atts){
	extract(shortcode_atts(array(
        'title'      => '',
       	'posts'      => '4',
       	'categories' => 'all',
		'columns'  =>  '4',
        'readmore_text' => 'Read More'				
    ), $atts));
    
    global $post;
	$blog_post_type = '';

	$args = array(
		'post_type' => 'post',
		'posts_per_page' => $posts,
		'order'          => 'DESC',
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );		
    $out = '';

	if( have_posts() ) : while ( have_posts() ) : the_post();

			    $out .= '';			

				$blog_thumbnail= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "blog-thumb" );
                $image = aq_resize( $blog_thumbnail[0], 175, 175, true, true, true );  
				$posttags = get_the_tags();

				$out .= '<li>';
				$out .= '<div class="thumbnail-md"><img src="'.esc_url($image).'" class="img-responsive pull-left" alt="image"></div>';
				$out .= '<div class="blog-right-klb">';
				$out .= '<a href="'.get_permalink().'"><h4>'.get_the_title().' </h4></a>';
				$out .= '<span class="time-stamp">'.get_the_date().' '.esc_html__('by','act').' '.get_the_author().'</span>';
				if ($posttags) {
				$out .= '<div class="tag-blog">';
				  foreach($posttags as $tag) {
                    $out .= '<a class="tag label label-secondary-light" href="javascript:void(0)"><i class="fa fa-tag"></i> '.$tag->name.'</a> ';
				  }
				$out .= '</div>';
				}
				$out .= '</div>';
				$out .= '</li>';
														
		endwhile;
		 wp_reset_query();
	endif;

	return  '
					<div id="custom-scrollbar-rec-news" class="custom-scrollbar">
					<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
						<div class="viewport">
							<ul class="list-unstyled list-vert-solid-line-bottom overview col-lg-11 col-xs-11">
							'.$out.'
							</ul>
						</div>
					</div>';
}
add_shortcode('blog', 'act_blog');


/*-----------------------------------------------------------------------------------*/
/*	Act Blog Masonry
/*-----------------------------------------------------------------------------------*/

function act_blog_masonry($atts){
	extract(shortcode_atts(array(
        'title'      => '',
       	'posts'      => '4',
       	'categories' => 'all',
		'columns'  =>  '4',
        'excerpt_size' => '15',
		'order' 	   => 'DESC',
        'beforepostlike'    => '160',						
    ), $atts));
    
    global $post;
	$blog_post_type = '';

	global $timebeforerevote;
	$timebeforerevote = $beforepostlike;

	wp_enqueue_style('isotope-doc');
	wp_enqueue_script('post-like');
	wp_enqueue_script('isotopes');
	wp_enqueue_script('custom-isotope');

	$args = array(
		'post_type' => 'post',
		'posts_per_page' => $posts,
		'order'          => $order,
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );		
    $out = '';

	if( have_posts() ) : while ( have_posts() ) : the_post();

			    $out .= '';			

				$blog_thumbnail= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "blog-thumb" );
                $image = aq_resize( $blog_thumbnail[0], 800, 530, true, true, true );  
				$posttags = get_the_tags();

				$out .= '<div class="post item">';
				$out .= '<div class="panel">';
				$out .= '<div class="panel-header">';
				$out .= '<img src="'.esc_url($blog_thumbnail[0]).'" class="img-responsive"  alt="'.get_the_title().'"/>';
				$out .= '</div>';
				$out .= '<div class="panel-body">';
				$out .= '<h3 class="post-title"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
				$out .= '<ul class="post-details list-unstyled list-inline">';
				$out .= '<li><p>'.esc_html__('by','act').' <a href="javascript:void(0)">'.get_the_author().'</a></p></li>';
				$out .= '<li class="separator">|</li>';
				$out .= '<li><p>'.get_the_date().'</p></li>';
				$out .= '<li class="separator">|</li>';
				$out .= '<li><p><a href="'.get_the_permalink().'">'.get_comments_number().' '.esc_html__( 'Comments', 'leeway' ) .'</a></p></li>';
				$out .= '</ul>';
				$out .= '<p>'.act_limit_words(get_the_excerpt(), $excerpt_size).'</p>';
				$out .= '<div class="pull-left"><a class="btn btn-black btn-xs" href="'.get_the_permalink().'"><span class="read-more">'.esc_html__('Read More','act').'</span></a></div>';
				$out .= '</div>';
				$out .= '<div class="panel-footer">';
				$out .= '<div class="pull-right">';
				$out .= getPostLikeLink(get_the_ID());
				$out .= '</div>';
				$out .= '<div class="clearfix"></div>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</div>';
														
		endwhile;
		 wp_reset_query();
	endif;

	return  '<div id="blog-isotope"><div class="posts">'.$out.'</div></div>';
}
add_shortcode('blog_masonry', 'act_blog_masonry');

/*-----------------------------------------------------------------------------------*/
/*	Act Events
/*-----------------------------------------------------------------------------------*/

function act_events($atts){
	extract(shortcode_atts(array(
        'title'      => '',
       	'posts'      => '6',
       	'categories' => 'all',
		'columns'  =>  '4',
        'readmore_text' => 'Read More',
        'date_type' => '',					
    ), $atts));
    
    global $post;
	$blog_post_type = '';

	$args = array(
		'post_type' => 'tribe_events',
		'posts_per_page' => $posts,
		'order'          => 'ASC',
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'tribe_events_cat',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );		
    $out = '';
     $i = 0;

	 $post_id =   
	 $count_posts = wp_count_posts( 'tribe_events' )->publish;
	 if( have_posts() ) : while ( have_posts() ) : the_post();
	
			    $out .= '';			

                if($date_type == 'startdate'){
	                $month = tribe_get_start_date($post, false, $format = "F");
	                $day = tribe_get_start_date($post, false, $format = "d");
	                $clock = tribe_get_start_date($post, false, $format = "g:i A");
                } else {
	                $month = tribe_get_end_date($post, false, $format = "F");
	                $day = tribe_get_end_date($post, false, $format = "d");
	                $clock = tribe_get_end_date($post, false, $format = "g:i A");
				}

				$blog_thumbnail= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "blog-thumb" );
                $image = aq_resize( $blog_thumbnail[0], 175, 175, true, true, true ); 
						    
				$out .= '<div class="col-lg-12 row-of-columns">';
				$out .= '<div class="col-md-3 bg-brand-primary">';
				$out .= '<div class="event-date text-center ">';
				$out .= '<h4 class="bold" >'. $month.'</h4>';
				$out .= '<h1>'.$day.'</h1>';   	
				$out .= '</div>';
				$out .= '</div>';
				$out .= '<div class="col-md-9">';
				$out .= '<span class="event-icon"><i class="fa fa-book fa-2x text-warning"></i></span>';
				$out .= '<a href="'.get_permalink().'"><h4>'.get_the_title().'</h4></a>';
				$out .= '<br>';
				$out .= '<ul class="list-inline list-unstyled event-details list-vert-solid-line-left">';
				$out .= '<li><i class="fa fa-clock-o"></i>&nbsp;&nbsp;'.$clock.' </li>';
				if(tribe_get_map_link()){
				$out .= '<li><i class="fa fa-map-marker"></i>&nbsp;&nbsp;'.tribe_get_map_link_html().'</li>';
				}
				$out .= '<li><a href="javascript:void(0)">'.tribe_get_city( get_the_ID() ).'</a> </li>';
				$out .= '</ul>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '<div class="clearfix"></div>';
				$out .= '<hr class="medium">';
				$i++;
				if ($i % 2 == 0 && ($i != $count_posts)  ) { 
				$out .= '</div><div class="item">';
				}


		endwhile;
		 wp_reset_query();
	endif;
	

	return  '	<div class="klb-event">
					<div class="carousel slide carousel-fade" id="carousel_2">
						<div class="carousel-inner">
                          <div class="item active">
                                '.$out.'
                           </div>
						</div>
						  <a class="left carousel-control" href="#carousel_2" role="button" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left text-secondary-lighter"></span>
						  </a>
						  <a class="right carousel-control" href="#carousel_2" role="button" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right text-secondary-lighter"></span>
						  </a>
					</div>
				</div>';
}
add_shortcode('events', 'act_events');

/*-----------------------------------------------------------------------------------*/
/*	Act Volunteer Box
/*-----------------------------------------------------------------------------------*/

function act_volunteer_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "name"             => '',
        "image_url"        => '',
		"warningmessage"   => '',
		"desc"             => '',
		"link"             => '',
    ), $atts) );
	
            $output = '';
			
		    $image_urls = wp_get_attachment_url( $image_url, 'full' );
			
			$link = ( '||' === $link ) ? '' : $link;
			$link = vc_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];

			$output .= '<div class="widget-new-volunteer">';
			$output .= '<div class="panel">';
			$output .= '<div class="label label-warning"> '.$warningmessage.'</div>';
			$output .= '<div class="panel-body">';
			if($a_href){
			$output .= '<a href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'">';
            }
			$output .= '<img src="'.esc_url($image_urls).'" alt="'.$name.'" class="img-responsive col-xs-12 no-padding">';
			if($a_href){
			$output .= '</a>';
			}
			$output .= '</div>';
			$output .= '<div class="panel-footer">';
			$output .= '<h4>'.$name.'</h4>';
			$output .= '<small>'.$desc.'</small>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';

  		return $output;
}

add_shortcode('volunteer_box', 'act_volunteer_box');


/*-----------------------------------------------------------------------------------*/
/*  Act Campaign Form
/*-----------------------------------------------------------------------------------*/

function act_campaign_form( $atts, $content = null ) {	
    extract( shortcode_atts(array(       
        "title"       => '',	
        "campaign_id"        => '',
		"image_url"    => '',		
    ), $atts) );

	$output = '';
	
	if($campaign_id){
	$output .= do_shortcode('[totaldonations form_id="'.$campaign_id.'"]');
    } else {
	$output .= do_shortcode('[totaldonations]');
    }
	
   return $output;

}

add_shortcode('campaign_form', 'act_campaign_form');

/*-----------------------------------------------------------------------------------*/
/*	Act Campaign Box
/*-----------------------------------------------------------------------------------*/

function act_campaign_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"            => '',
        "image_url"        => '',
		"campaign_id"      => '',
		"desc"             => '',
		"link"             => '',
		"duedate"          => '',
    ), $atts) );
	
            $output = '';
			
		    $image_urls = wp_get_attachment_url( $image_url, 'full' );

			$christmas = strtotime($duedate);
			$now = time();
			$timeleft = $christmas-$now;
			$daysleft = round((($timeleft/24)/60)/60);

			$output .= '<div class="panel campaign-box">';
			$output .= '<div class="panel-header">';
			if($image_url){
			$output .= '<img src="'.esc_url($image_urls).'" class="img-responsive no-padding"  alt="image"/>';
			}
			$output .= '<div class="clearfix"></div>';
			$output .= '</div>';
			$output .= '<div class="panel-body">';
			$output .= '<h4>'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" button="yes"]').'<a>'.$title.'</a></h4>';
			$output .= '<p>'.do_shortcode($content).'</p>';
			$output .= '<div class="col-lg-12 no-padding">';
			$output .= '<p>'.do_shortcode('[totaldonations-progress-bar campaign="'.$title.'" button="no" text="no"]').'</p>';
			$output .= '</div></div><div class="clearfix"></div>';
			$output .= '<div class="panel-footer text-center">';
			$output .= '<div class="col-xs-4">';
			$output .= '<h3>'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#percentage#"]').'</h3>';
			$output .= '<small>'.esc_html__('Funded','act').'</small>';
			$output .= '</div>';
			$output .= '<div class="col-xs-4">';
			$output .= '<h3>'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#target#"]').' </h3>';
			$output .= '<small>'.esc_html__('Target','act').'</small>';
			$output .= '</div>';
			$output .= '<div class="col-xs-4">';
			$output .= '<h3>'.$daysleft.'</h3>';
			$output .= '<small>'.esc_html__('Days Left','act').'</small>';
			$output .= '</div>';
			$output .= '<div class="clearfix"></div>';
			$output .= '</div>';
			$output .= '</div>';

  		return $output;
}

add_shortcode('campaign_box', 'act_campaign_box');


/*-----------------------------------------------------------------------------------*/
/*	Act Fundraise Bar
/*-----------------------------------------------------------------------------------*/

function act_fundraise_bar( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"            => '',
        "image_url"        => '',
		"campaign_id"      => '',
		"desc"             => '',
		"link"             => '',
		"duedate"          => '',
		"translate_goal"   		  => 'Goal',
		"translate_of_our_goal"   => 'of our goal',
		"translate_days_left"     => 'Days Left',
		"translate_donations"     => 'Donations',
    ), $atts) );
	
            $output = '';
			
		    $image_urls = wp_get_attachment_url( $image_url, 'full' );
			
			ob_start();
			 $target = migla_get_target($title); //toplanan
			 $total = migla_get_total_amount($title);
			 
             $totalstr = str_replace(array('$',',','.'),'',$total);
             $targetstr = str_replace(array('$',',','.'),'',$target);

			 $c = $targetstr / 100; 

             $percent = floor($totalstr / $c); // yuvarlama


			 
			$christmas = strtotime($duedate);
			$now = time();
			$timeleft = $christmas-$now;
			$daysleft = round((($timeleft/24)/60)/60);

			$donater = do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#backers#"]');
			$output .= '<div id="fundraiser-bar" class="bottom-bar-responsive bg-brand-secondary-darkest">';
			$output .= '<div class="col-md-6 fundraiser-progress-bar animated-longer-delay-3 fadeIn">';
			$output .= '<div class="vert-centered-wrapper-120px">';
			$output .= '<div class="vert-centered">';
			$output .= '<div class="progress">';
			$output .= '<div class="progress-bar progress-bar-tertiary" role="progressbar"  style="width:'.$percent.'%;">';
			$output .= '<h3><span class="responsive-hide">'.$title.'</span> &nbsp;<b>'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#total#"]').'</b></h3>';
			$output .= '</div>';
			$output .= '<h3 class="goal"><span class="responsive-hide">'.esc_html($translate_goal).'</span> <b>'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#target#"]').'</b></h3>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="col-md-4 col-sm-9 col-xs-12 fundraiser-stats">';
			$output .= '<div class="col-md-4 col-sm-4  col-xs-4 animated-longer-delay-7 fadeIn">';
			$output .= '<div class="vert-centered-wrapper-120px">';
			$output .= '<div class="vert-centered">	';
			$output .= '<h2><span class="timer" data-to="'.$percent.'" >'.$percent.'</span>%</h2>';
			$output .= '<h4>'.esc_html($translate_of_our_goal).'</h4>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="col-md-4 col-sm-4 col-xs-4 animated-longer-delay-8 fadeIn">';
			$output .= '<div class="vert-centered-wrapper-120px">';
			$output .= '<div class="vert-centered">';
			$output .= '<h2><span class="timer" data-to="'.$daysleft.'" data-speed="1000">'.$daysleft.'</span></h2>';
			$output .= '<h4>'.esc_html($translate_days_left).'</h4>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="col-md-4 col-sm-4 col-xs-4 animated-longer-delay-9 fadeIn end">';
			$output .= '<div class="vert-centered-wrapper-120px">';
			$output .= '<div class="vert-centered">	';
			$output .= '<h2><span class="timer" data-to="1223" data-speed="2500">'.do_shortcode('[totaldonations-text-fields campaign="'.$title.'" text="#backers#"]').'</span></h2>';
			$output .= '<h4>'.esc_html($translate_donations).'</h4>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div><div class="clearfix"></div>';
			$output .= '</div>';
			$output .= '<div class="col-md-2 col-sm-3 col-xs-12  make-a-donation  animated-longer-delay-10 fadeIn">';
			$output .= '<div class="vert-centered-wrapper-120px">';
			$output .= '<div class="vert-centered">	';
			$output .= do_shortcode('[totaldonations-text-fields campaign="'.$title.'" button="yes"]');
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
  		return $output;
}

add_shortcode('fundraise_bar', 'act_fundraise_bar');


/*-----------------------------------------------------------------------------------*/
/*	Act Button Btn
/*-----------------------------------------------------------------------------------*/

function act_btn_button( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "icon_fontawesome"    => '',
		"button_icon"         => '',
        "link"                => '',
        "btnalignment"	      => '',
        "button_size"	      => '',		
		"icon_alignment"      => '',
		"css"       		  => '',
		"bgcolor"             => '#000',
		"fontcolor"           => '#fff',
		"bordercolor"         => '#000',
		"hoverbgcolor"        => '#404040',
		"hoverfontcolor"      => '#fff',
		"hoverbordercolor"    => '#404040',
		"button_type"   	  => '',
		"buttonname"          => '',
		"modal_id"          => '',
    ), $atts) );

	        $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
			
			$link = ( '||' === $link ) ? '' : $link;
			$link = vc_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			
            $output         = '';
			$klb            = '';
			$size           = '';
			$alignment   = '';

			if($button_size == '2'){
			  $size .= 'btn-big';
			} elseif($button_size == '3'){
			  $size .= 'btn-small';	
			} else {
			  $size .= '';	
			}

			if($btnalignment == 'center'){
			  $alignment .= 'text-center';
			} elseif($btnalignment == 'right'){
			  $alignment .= 'text-right';	
			} else {
			  $alignment .= 'text-left';	
			}
?>
			<style>
			
			 <?php $bgcolor22 = str_replace(array('#','.',',','(',')'),'',$hoverbgcolor); ?>
			 <?php $fontcolor22 = str_replace(array('#','.',',','(',')'),'',$hoverfontcolor); ?>
			 <?php $bordercolor22 = str_replace(array('#','.',',','(',')'),'',$hoverbordercolor); ?>

			.btn.klb_<?php echo $bgcolor22 ?>:hover {
				background-color: <?php echo esc_html($hoverbgcolor); ?> !important;
			}
			
			.btn.klb_<?php echo $fontcolor22 ?>:hover {
				color: <?php echo esc_html($hoverfontcolor); ?> !important;
			}

			.btn.klb_<?php echo $bordercolor22 ?>:hover {
				border-color: <?php echo esc_html($hoverbordercolor); ?> !important;
			}
			
			</style>
<?php

            $output .= '<div class="'.esc_attr($alignment) . esc_attr( $css_class ).'">';
			if($button_type == 'modal'){
            $output .= '<div class="remodal" data-remodal-id="'.esc_attr($modal_id).'">';
            $output .= '<button data-remodal-action="close" class="remodal-close"></button>';
            $output .= do_shortcode($content);                 
            $output .= '</div>';
            $output .= '<a class="btn btn-black klb_'.$bgcolor22.' klb_'.$fontcolor22.' klb_'.$bordercolor22.' '.$size.'" href="#'.esc_attr( $modal_id ).'" title="'.esc_attr( $buttonname ).'" style="color:'.esc_attr($fontcolor).';background-color:'.esc_attr($bgcolor).'; border:2px solid '.esc_attr($bordercolor).';">';
			} else {
            $output .= '<a class="btn btn-black klb_'.$bgcolor22.' klb_'.$fontcolor22.' klb_'.$bordercolor22.' '.$size.'" href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'" style="color:'.esc_attr($fontcolor).';background-color:'.esc_attr($bgcolor).'; border:2px solid '.esc_attr($bordercolor).';">';
			}

   			    if($button_icon == true){
				  if($icon_alignment == 'right'){
				    
				  } else {
					$output .= '<i class="'.$icon_fontawesome.'"></i> ';
				  }
				}
			if($button_type == 'modal'){
            $output .= esc_attr( $buttonname );
			} else {
            $output .= esc_attr( $a_title );
			}
				if($button_icon == true){
				  if($icon_alignment == 'right'){
				    $output .= ' <i class="'.$icon_fontawesome.'"></i>';
				  }
				}			
			$output .= '</a>';

			$output .= '</div>';

  		return $output;
}

add_shortcode('btn_button', 'act_btn_button');

/*-----------------------------------------------------------------------------------*/
/*	Act Latest Portfolio
/*-----------------------------------------------------------------------------------*/

function act_portfolio($atts){
	extract(shortcode_atts(array(
       	'posts'      => '5',
       	'categories' => 'all',
        'filter'    => '',
        'title'     => 'Recent Projects'
    ), $atts));
	
	wp_enqueue_script('custom-pretty'); 

    global $post;
	$blog_post_type = '';
    $portfolio_filters = get_terms('portfolio_category');

    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$args = array(
		'post_type' => 'portfolio',
		'posts_per_page' => $posts,
		'order'          => 'DESC',
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories,
        'paged' 			=> $paged
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'portfolio_category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );		
    $out = '';
    $out1 = '';
	
	         if($title){
				$out1 .= '<div class="col-lg-4 col-sm-6 col-xs-12 no-padding bg-brand-tertiary wow animated fadeIn text-center">';
				$out1 .= '<div class=" col-xs-12 float-over-top-center">';
				$out1 .= '<h1 class="text-uppercase">'.$title;
				$out1 .= '<span class="responsive-hide">';
				$out1 .= ' <i class="fa fa-caret-right transparent-30"></i>';
				$out1 .= '</span>';
				$out1 .= '</h1>';
				$out1 .= '</div>';
				$out1 .= '<img style="width:100%;" src="'.get_template_directory_uri().'/img/gal-spacer.png" alt="gallery" class="img-responsive">'; 
				$out1 .= '</div>';
	        }
	        if( have_posts() ) : while ( have_posts() ) : the_post();	

				$blog_thumbnail= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "squarefolio-portfolio-thumb" );
				$blog_image= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" );				 
				$image = aq_resize( $blog_image[0], 600, 390, true, true, true );   

                $terms = get_the_terms( get_the_ID(), 'portfolio_category' );
                $taxonomy = strip_tags( get_the_term_list($post->ID, 'portfolio_category', '', ', ', '') );
				
				$post_format = '';
				if( get_post_meta( get_the_ID(), 'klb_project_video_embed', true ) != "") {	
					if (get_post_meta( get_the_ID(), 'klb_project_video_type', true ) == 'vimeo') { 
					  $post_format .='http://vimeo.com/'.get_post_meta( get_the_ID(), 'klb_project_video_embed', true );
					} else if (get_post_meta( get_the_ID(), 'klb_project_video_type', true ) == 'youtube') { 
					  $post_format .='http://www.youtube.com/watch?v='.get_post_meta( get_the_ID(), 'klb_project_video_embed', true );
					}
			    } else {
					$post_format .= $blog_image[0];
				}
				$out .= '<div class="img col-lg-4 col-sm-6 col-xs-12 no-padding tn wow animated-longer-delay-2 fadeIn">';
				$out .= '<div class="gallery effects-container effects-enlarge">';
				$out .= '<a href="'.$post_format.'" alt="<b>'.get_the_title().'</b><br> '. get_the_content() .'"  rel="prettyPhoto[galleryName]">';
				$out .= '<img src="'.esc_url($image).'" alt="'.get_the_title().'" />';
				$out .= '<div class="overlay">';
				$out .= '<span class="expand"><i class=" fa fa-chevron-right"></i></span>';
				$out .= '<div class="overlay-caption">';
				$out .= '<h3>'.get_the_title().'</h3>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</a>';
				$out .= '</div>';
				$out .= '</div>';		   		
		   
			endwhile;
		 wp_reset_query();
	endif;

	return  '<div id="effect-1" class="effects clearfix gallery">'.$out1 . $out.'</div>';
}
add_shortcode('portfolio', 'act_portfolio');


/*-----------------------------------------------------------------------------------*/
/*	Act Latest Portfolio Two
/*-----------------------------------------------------------------------------------*/

function act_portfolio_two($atts){
	extract(shortcode_atts(array(
       	'posts'      => '5',
       	'categories' => 'all',
        'filter'    => '',
        'all_text'  => 'All',

    ), $atts));

	wp_enqueue_style('cubeportfolio'); 
	wp_enqueue_script('cubeportfolio'); 
	wp_enqueue_script('custom-cube'); 

    global $post;
	$blog_post_type = '';
    $portfolio_filters = get_terms('portfolio_category');

    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$args = array(
		'post_type' => 'portfolio',
		'posts_per_page' => $posts,
		'order'          => 'DESC',
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories,
        'paged' 			=> $paged
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'portfolio_category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );
    $portfolio_filters = get_terms('portfolio_category');
		
    $out = '';
    $out1 = '';
	           if($filter == true) {
          	     if($portfolio_filters):

				 $out1 .= '<div class="js-filters-juicy-projects cbp-l-filters-button cbp-l-filters-alignCenter">';
				 $out1 .= '<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">'.esc_html($all_text).'<div class="cbp-filter-counter"></div></div>';

				 foreach($portfolio_filters as $portfolio_filter):	
					 if($categories == 'all'){
						 
				         $out1 .= '<div data-filter=".'.esc_attr($portfolio_filter->slug).'" class="cbp-filter-item">'.esc_attr($portfolio_filter->name).' <div class="cbp-filter-counter"></div></div>';

					 } else {
				         $str = str_replace(',',' ',$categories);
				         $category = explode(' ',$str);
						 if ( in_array( $portfolio_filter->slug, $category ) ) { 
						 
				         $out1 .= '<div data-filter=".'.esc_attr($portfolio_filter->slug).'" class="cbp-filter-item">'.esc_attr($portfolio_filter->name).' <div class="cbp-filter-counter"></div></div>';

						 }
					 }

	             endforeach;
				 $out1 .= '</div>'; 
                 endif;
            }

	        if( have_posts() ) : while ( have_posts() ) : the_post();	

				$blog_image= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" );				 
				$image = aq_resize( $blog_image[0], 600, 390, true, true, true );   

                $terms = get_the_terms( get_the_ID(), 'portfolio_category' );
                $taxonomy = strip_tags( get_the_term_list($post->ID, 'portfolio_category', '', ', ', '') );

				$out .= '<div class="cbp-item ';
				if($terms) : foreach ($terms as $term) {
					$out .= $term->slug.' '; 
				} endif;
				$out .= '">';
				$out .= '<div class="cbp-caption">';
				$out .= '<div class="cbp-caption-defaultWrap">';
				$out .= '<img src="'.$image.'" alt="'.get_the_title().'">';
				$out .= '</div>';
				$out .= '<div class="cbp-caption-activeWrap">';
				$out .= '<div class="cbp-l-caption-alignCenter">';
				$out .= '<div class="cbp-l-caption-body">';
				$out .= '<a href="'.esc_url( home_url( '/' ) ).'portfolio/'.$post->post_name.'" class="cbp-singlePage cbp-l-caption-buttonLeft btn btn-black ">'.esc_html__('more info','act').'</a>';
				$out .= '<a href="'.$blog_image[0].'" class="btn btn-black cbp-lightbox cbp-l-caption-buttonRight" data-title="'.get_the_title().'">'.esc_html__('view larger','act').'</a>';
				$out .= '<div class="cbp-l-grid-projects-desc">'.get_the_title().'</div>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</div>';		   		
		   
			endwhile;
		 wp_reset_query();
	endif;

	return  $out1.'<div class="js-grid-juicy-projects cbp">'.$out.'</div>';
}
add_shortcode('portfolio_two', 'act_portfolio_two');


/*-----------------------------------------------------------------------------------*/
/*	Act Action Box
/*-----------------------------------------------------------------------------------*/

function act_action_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"              => '',
        "icon_fontawesome"   => '',
        "icon_openiconic"   => '',
        "icon_typicons"   => '',
        "icon_entypo"   => '',
        "icon_linecons"   => '',
        "icon_monosocial"   => '',
		"type"               => '',
    ), $atts) );
	
            $output = '';
            vc_icon_element_fonts_enqueue( $type ); 
			$output .= '<div class="action-box">';
			$output .= '<a class="btn  btn-white text-big"><i class="text-primary '. $icon_fontawesome . $icon_openiconic . $icon_typicons . $icon_entypo . $icon_linecons . $icon_monosocial.'"></i></a>';
			$output .= '<h3>'.$title.'</h3>';
			$output .= '<p>'.do_shortcode($content).'</p>';
			$output .= '</div>';
  		return $output;
}

add_shortcode('action_box', 'act_action_box');

/*-----------------------------------------------------------------------------------*/
/*  Act Map Container
/*-----------------------------------------------------------------------------------*/

function act_map_container( $atts, $content = null ) {	
$css = '';
 	extract(shortcode_atts(array(
       	'latitude'      => '51.5209564',
       	'longitude' => '0.157134',
        'zoom'      => '10',
        'css' => '',
        'height' => '400',	
        'mapimage' => '',	
    ), $atts)); 
	$image_urls = wp_get_attachment_url( $mapimage, 'full' );	
    wp_enqueue_script('googlemap');
?>

<script type="text/javascript">
jQuery(document).ready(function() {
function initialize() {
	
var styles = [
    {
      stylers: [
        { hue: "#eec55b" },
        { saturation: -100 },
        { gamma: 0.9 }
      ]
    },{
      featureType: "road",
      elementType: "geometry",
      stylers: [
        { lightness: 100 },
        { visibility: "simplified" }
      ]
    },{
      featureType: "road",
      elementType: "labels",
      stylers: [
        { visibility: "on" }
      ]
    }
  ];
    var styledMap = new google.maps.StyledMapType(styles,
    {name: "Gray Map"});  
	
    var latlng = new google.maps.LatLng(<?php echo esc_attr($latitude); ?>,<?php echo esc_attr($longitude); ?>);
    var myOptions = {
        zoom: <?php echo esc_attr($zoom); ?>,
        center: latlng,
        scrollwheel: false,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
		mapTypeControlOptions: {
		  mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
		}
    };

    var map = new google.maps.Map(document.getElementById("map"),
            myOptions);
  map.mapTypes.set('map_style', styledMap);
  map.setMapTypeId('map_style');
  
  var markerimage = '<?php echo esc_url($image_urls); ?>';
  var marker = new google.maps.Marker({
    position: {lat: <?php echo esc_attr($latitude); ?>, lng: <?php echo esc_attr($longitude); ?>},
    map: map,
    icon: markerimage,
  });
  
}
google.maps.event.addDomListener(window, "load", initialize);
});
</script>

<?php 
            $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	        $output = '';
			
            $output .= '<div class="contact-map '.esc_attr( $css_class ).'">
                <div id="map" class="google-map" style="height:'.esc_attr($height).'px;"></div>
            </div>';

   return $output;

}

add_shortcode('map_container', 'act_map_container');


/*-----------------------------------------------------------------------------------*/
/*	Act Toggle Bar
/*-----------------------------------------------------------------------------------*/

function act_toggle_bar( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "buttonname"              => '',
        "toggleid"              => '',
    ), $atts) );
	
            $output = '';
			
			$output .= '<div class="span4 collapse-group toggle-content">';
            $output .= '<div id="'.$toggleid.'" class="bg-brand-tertiary collapse">';
            $output .= '<div class="inner-container animated fadeIn">';
            $output .= do_shortcode($content);
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '<div class="toggle-container">';
            $output .= '<div class="bg-brand-tertiary thin-strip">&nbsp;</div>';
			$output .= '<div class="float-over-top">';
            $output .= '<div id="contact-toggle" class="tab-down tab-down-tertiary"><a class="" data-toggle="collapse" data-target="#'.$toggleid.'"><h3>'.$buttonname.' <i class="fa fa-chevron-down"></i></h3></a></div>';
            $output .= '</div>';
            $output .= '</div>';
  		return $output;
}

add_shortcode('toggle_bar', 'act_toggle_bar');

/*-----------------------------------------------------------------------------------*/
/*	Act Donor Box
/*-----------------------------------------------------------------------------------*/

function act_donor_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "name"              => '',
        "image_url"              => '',
        "subtitle"              => '',
    ), $atts) );
	
            $output = '';

			$image_urls = wp_get_attachment_url( $image_url, 'full' );
			wp_enqueue_script('custom-pretty'); 

			
			$output .= '<div id="effect-1" class="effects clearfix">';
			$output .= '<div class="img">';
			$output .= '<div class="gallery effects-container effects-enlarge">';
			$output .= '<a href="'.esc_url($image_urls).'" alt="'.do_shortcode($content).'"  rel="prettyPhoto[1]">';
			$output .= '<img src="'.esc_url($image_urls).'" alt="'.$name.'"/>';
			$output .= '<div class="overlay">';
			$output .= '<div class="overlay-caption-style-2">';
			$output .= '<h3>'.$name.'</h3>';
			$output .= '<small>'.$subtitle.'</small>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</a>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			
  		return $output;
}

add_shortcode('donor_box', 'act_donor_box');

/*-----------------------------------------------------------------------------------*/
/*	Act Team Box
/*-----------------------------------------------------------------------------------*/

function act_team_box( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "name"              => '',
        "image_url"              => '',
        "subtitle"              => '',
        "values"              => '',
        "icon_fontawesome"    => '',
        "link"    => '',
    ), $atts) );
	
            $output = '';
            $values = (array) vc_param_group_parse_atts($values);
			$image_urls = wp_get_attachment_url( $image_url, 'full' );
			
			$output .= '<div class="panel team-members text-center">';
			$output .= '<div class="panel-body">';                             
			$output .= '<div class="col-xs-12">';
			$output .= '<div class="avatar-team-member">';
			$output .= '<img src="'.esc_url($image_urls).'" alt="'.$name.'">'; 
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<h3>'.$name.'</h3>';
			$output .= '<h4>'.$subtitle.' </h4>';
			$output .= '<p> '.do_shortcode($content).'  </p>';
			
			
			$output .= '<ul class="list-unstyled list-inline list-social-sq-primary">';
			foreach($values as $v){
				$link = ( '||' === $v['link'] ) ? '' : $v['link'];
				$link = vc_build_link( $v['link'] );
				$a_href = $link['url'];
				$a_title = $link['title'];
				$a_target = $link['target'];
			$output .= '<li><a href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'"><i class="'.$v['icon_fontawesome'].'"></i></a></li> ';
			}
			$output .= '</ul>';

			$output .= '</div>';
			$output .= '</div>';
			
  		return $output;
}

add_shortcode('team_box', 'act_team_box');

/*-----------------------------------------------------------------------------------*/
/*	Br-Tag
/*-----------------------------------------------------------------------------------*/

function act_br() {
   return '<br />';
}

 add_shortcode('br', 'act_br');